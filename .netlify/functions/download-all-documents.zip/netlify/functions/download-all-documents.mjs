
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/download-all-documents.ts
var download_all_documents_default = async (request, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 200, headers });
  }
  try {
    const { contractId, codiceOfferta } = await request.json();
    if (!contractId || !codiceOfferta) {
      return new Response(JSON.stringify({
        error: "ContractId e codiceOfferta sono richiesti"
      }), { status: 400, headers });
    }
    const mockZipContent = generateMockZIP(codiceOfferta);
    return new Response(mockZipContent, {
      status: 200,
      headers: {
        ...headers,
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="Documenti_${codiceOfferta}.zip"`,
        "Content-Length": mockZipContent.length.toString()
      }
    });
  } catch (error) {
    console.error("\u274C Download all documents error:", error);
    return new Response(JSON.stringify({
      error: "Internal server error",
      details: error.message
    }), { status: 500, headers });
  }
};
function generateMockZIP(codiceOfferta) {
  const zipContent = `PK\0\0\0\b\0\0\0!\0`;
  const files = [
    `Contratto_${codiceOfferta}.pdf`,
    `Documento_Identita_${codiceOfferta}.pdf`,
    `Bolletta_${codiceOfferta}.pdf`,
    `Fatture_${codiceOfferta}.pdf`
  ];
  let zipData = zipContent;
  files.forEach((filename, index) => {
    zipData += `${filename}\0`;
    zipData += `Contenuto mock del file ${filename} generato il ${(/* @__PURE__ */ new Date()).toISOString()}\0`;
  });
  zipData += `PK\0\0\0\0\0\0\xFF\xFF\xFF\xFF\0\0`;
  const encoder = new TextEncoder();
  return encoder.encode(zipData).buffer;
}
export {
  download_all_documents_default as default
};
