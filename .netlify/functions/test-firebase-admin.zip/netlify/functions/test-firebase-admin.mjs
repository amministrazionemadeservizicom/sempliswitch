
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/firebase-admin.ts
var firebase_admin_exports = {};
__export(firebase_admin_exports, {
  adminAuth: () => adminAuth,
  adminDb: () => adminDb,
  adminOperations: () => adminOperations,
  default: () => firebase_admin_default,
  isFirebaseAvailable: () => isFirebaseAvailable
});
import admin from "firebase-admin";
import { getFirestore } from "firebase-admin/firestore";
import * as path from "path";
import fs from "fs";
var isFirebaseInitialized, adminDb, adminAuth, firebase_admin_default, isFirebaseAvailable, adminOperations;
var init_firebase_admin = __esm({
  "server/firebase-admin.ts"() {
    isFirebaseInitialized = false;
    if (!admin.apps.length) {
      try {
        console.log("\u{1F525} Initializing Firebase Admin SDK...");
        if (process.env.FIREBASE_PRIVATE_KEY && process.env.FIREBASE_CLIENT_EMAIL) {
          console.log("\u{1F4CB} Using Firebase credentials from environment variables...");
          const serviceAccount = {
            projectId: process.env.FIREBASE_PROJECT_ID || "sempliswitch",
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n")
          };
          admin.initializeApp({
            credential: admin.credential.cert(serviceAccount),
            projectId: "sempliswitch"
          });
          isFirebaseInitialized = true;
          console.log("\u2705 Firebase Admin SDK initialized with environment variables");
        } else {
          const serviceAccountPath = path.join(process.cwd(), "credentials", "firebase-admin-credentials.json");
          console.log("\u{1F4C1} Trying service account file:", serviceAccountPath);
          if (fs.existsSync(serviceAccountPath)) {
            const serviceAccountContent = fs.readFileSync(serviceAccountPath, "utf8");
            const serviceAccount = JSON.parse(serviceAccountContent);
            if (serviceAccount.private_key && serviceAccount.private_key.length > 100) {
              admin.initializeApp({
                credential: admin.credential.cert(serviceAccountPath),
                projectId: "sempliswitch"
              });
              isFirebaseInitialized = true;
              console.log("\u2705 Firebase Admin SDK initialized with service account file");
            } else {
              console.warn("\u26A0\uFE0F Service account file has incomplete private key");
              throw new Error("Incomplete private key in service account file");
            }
          } else {
            console.warn("\u26A0\uFE0F Service account file not found:", serviceAccountPath);
            throw new Error("Service account file not found");
          }
        }
      } catch (error) {
        console.error("\u274C Failed to initialize Firebase Admin SDK:", error);
        console.log(`
\u{1F527} To fix this Firebase Admin authentication issue:

METHOD 1 - Environment Variables (Recommended):
Set these environment variables:
- FIREBASE_PROJECT_ID=sempliswitch
- FIREBASE_CLIENT_EMAIL=firebase-adminsdk-fbsvc@sempliswitch.iam.gserviceaccount.com
- FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\\nYour\\nComplete\\nPrivate\\nKey\\n-----END PRIVATE KEY-----\\n"

METHOD 2 - Fix Service Account File:
Ensure the credentials/firebase-admin-credentials.json file has a complete private_key field

For now, the system will operate in fallback mode with limited functionality.
    `);
        isFirebaseInitialized = false;
      }
    }
    adminDb = isFirebaseInitialized ? getFirestore() : null;
    adminAuth = isFirebaseInitialized ? admin.auth() : null;
    firebase_admin_default = admin;
    isFirebaseAvailable = () => isFirebaseInitialized;
    adminOperations = {
      // Create user with custom claims
      async createUserWithRole(userData) {
        if (!isFirebaseInitialized || !adminAuth || !adminDb) {
          throw new Error("Firebase Admin SDK not properly initialized. Please check credentials.");
        }
        try {
          const userRecord = await adminAuth.createUser({
            email: userData.email,
            password: userData.password,
            displayName: userData.cognome ? `${userData.nome} ${userData.cognome}` : userData.nome
          });
          await adminAuth.setCustomUserClaims(userRecord.uid, {
            role: userData.ruolo
          });
          await adminDb.collection("utenti").doc(userRecord.uid).set({
            uid: userRecord.uid,
            email: userData.email,
            nome: userData.nome,
            cognome: userData.cognome || "",
            ruolo: userData.ruolo,
            attivo: true,
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
            ...userData
          });
          console.log("\u2705 User created successfully:", userRecord.uid);
          return userRecord;
        } catch (error) {
          console.error("\u274C Error creating user:", error);
          throw error;
        }
      },
      // Get all contracts with admin privileges
      async getAllContracts() {
        if (!isFirebaseInitialized || !adminDb) {
          console.warn("\u26A0\uFE0F Firebase not available, returning empty contracts list");
          return [];
        }
        try {
          const snapshot = await adminDb.collection("contracts").get();
          return snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data()
          }));
        } catch (error) {
          console.error("\u274C Error fetching contracts:", error);
          return [];
        }
      },
      // Update contract status with admin privileges
      async updateContractStatus(contractId, status, notes) {
        if (!isFirebaseInitialized || !adminDb) {
          throw new Error("Firebase Admin SDK not properly initialized. Cannot update contract status.");
        }
        try {
          await adminDb.collection("contracts").doc(contractId).update({
            statoOfferta: status,
            noteStatoOfferta: notes || "",
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
          });
          console.log("\u2705 Contract status updated:", contractId);
          return true;
        } catch (error) {
          console.error("\u274C Error updating contract:", error);
          throw error;
        }
      },
      // Update full contract with admin privileges
      async updateContract(contractId, updateData) {
        if (!isFirebaseInitialized || !adminDb) {
          throw new Error("Firebase Admin SDK not properly initialized. Cannot update contract.");
        }
        try {
          const updateFields = {
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
          };
          if (updateData.statoOfferta) updateFields.statoOfferta = updateData.statoOfferta;
          if (updateData.noteStatoOfferta !== void 0) updateFields.noteStatoOfferta = updateData.noteStatoOfferta;
          if (updateData.contatto) updateFields.contatto = updateData.contatto;
          if (updateData.ragioneSociale !== void 0) updateFields.ragioneSociale = updateData.ragioneSociale;
          await adminDb.collection("contracts").doc(contractId).update(updateFields);
          console.log("\u2705 Contract updated:", contractId);
          return true;
        } catch (error) {
          console.error("\u274C Error updating contract:", error);
          throw error;
        }
      },
      // Save new contract with admin privileges
      async saveContract(contractData, userId, userName, userSurname, masterReference) {
        if (!isFirebaseInitialized || !adminDb) {
          throw new Error("Firebase Admin SDK not properly initialized. Cannot save contract.");
        }
        try {
          const timestamp = Date.now();
          const codiceUnivocoOfferta = `CON-${timestamp}`;
          const tipologiaContratto = contractData.offerte.some(
            (offer) => offer.serviceType === "Luce" || offer.serviceType === "Gas"
          ) ? "energia" : "telefonia";
          const gestore = contractData.offerte[0]?.brand || "UNKNOWN";
          const contractForFirebase = {
            codiceUnivocoOfferta,
            dataCreazione: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
            // YYYY-MM-DD format
            creatoDa: {
              id: userId,
              nome: userName,
              cognome: userSurname
            },
            contatto: {
              nome: contractData.cliente.nome,
              cognome: contractData.cliente.cognome,
              codiceFiscale: contractData.cliente.codiceFiscale
            },
            isBusiness: false,
            // Default to residential
            statoOfferta: "Caricato",
            noteStatoOfferta: "Contratto appena creato",
            gestore,
            masterReference: masterReference || "",
            tipologiaContratto,
            // Additional detailed data
            dettagliCliente: {
              cellulare: contractData.cliente.cellulare,
              email: contractData.cliente.email,
              iban: contractData.cliente.iban || null
            },
            documento: contractData.documento,
            indirizzi: contractData.indirizzi,
            datiTecnici: {
              pod: contractData.pod || null,
              pdr: contractData.pdr || null,
              potenzaImpegnataKw: contractData.potenzaImpegnataKw || null,
              usiGas: contractData.usiGas || [],
              residenziale: contractData.residenziale || null
            },
            offerte: contractData.offerte || [],
            // Timestamps
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
          };
          const cleanedContract = this.cleanUndefinedValues(contractForFirebase);
          console.log("\uFFFD\uFFFD\uFFFD Saving contract via Admin SDK:", cleanedContract);
          const docRef = await adminDb.collection("contracts").add(cleanedContract);
          console.log("\u2705 Contract saved successfully with ID:", docRef.id);
          return {
            success: true,
            contractId: docRef.id,
            codiceUnivocoOfferta
          };
        } catch (error) {
          console.error("\u274C Error saving contract via Admin SDK:", error);
          throw error;
        }
      },
      // Helper function to clean undefined values
      cleanUndefinedValues(obj) {
        if (obj === null || obj === void 0) {
          return null;
        }
        if (Array.isArray(obj)) {
          return obj.map((item) => this.cleanUndefinedValues(item)).filter((item) => item !== void 0);
        }
        if (typeof obj === "object") {
          const cleaned = {};
          for (const [key, value] of Object.entries(obj)) {
            if (value !== void 0) {
              cleaned[key] = this.cleanUndefinedValues(value);
            }
          }
          return cleaned;
        }
        return obj;
      },
      // Delete contract with admin privileges
      async deleteContract(contractId) {
        if (!isFirebaseInitialized || !adminDb) {
          throw new Error("Firebase Admin SDK not properly initialized. Cannot delete contract.");
        }
        try {
          await adminDb.collection("contracts").doc(contractId).delete();
          console.log("\u2705 Contract deleted:", contractId);
          return true;
        } catch (error) {
          console.error("\u274C Error deleting contract:", error);
          throw error;
        }
      }
    };
  }
});

// netlify/functions/test-firebase-admin.ts
var test_firebase_admin_default = async (request, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Content-Type": "application/json"
  };
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 200, headers });
  }
  if (request.method !== "GET") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers
    });
  }
  try {
    console.log("\u{1F9EA} Testing Firebase Admin SDK...");
    const { adminDb: adminDb2, adminAuth: adminAuth2, adminOperations: adminOperations2 } = await Promise.resolve().then(() => (init_firebase_admin(), firebase_admin_exports));
    const contractsSnapshot = await adminDb2.collection("contracts").limit(1).get();
    const contractsCount = contractsSnapshot.size;
    const usersResult = await adminAuth2.listUsers(1);
    const usersCount = usersResult.users.length;
    const allContracts = await adminOperations2.getAllContracts();
    return new Response(JSON.stringify({
      success: true,
      message: "Firebase Admin SDK is working correctly",
      tests: {
        firestore: {
          status: "OK",
          contractsInDatabase: allContracts.length
        },
        authentication: {
          status: "OK",
          usersFound: usersCount
        },
        adminOperations: {
          status: "OK",
          operationsAvailable: Object.keys(adminOperations2).length
        }
      },
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }), { status: 200, headers });
  } catch (error) {
    console.error("\u274C Firebase Admin test failed:", error);
    return new Response(JSON.stringify({
      success: false,
      error: "Firebase Admin SDK test failed",
      details: error.message,
      code: error.code || "UNKNOWN_ERROR"
    }), { status: 500, headers });
  }
};
export {
  test_firebase_admin_default as default
};
