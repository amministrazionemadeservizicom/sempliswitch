
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-contracts.ts
var adminApi = {
  // Get all contracts using admin privileges
  async getAllContracts() {
    try {
      const response = await fetch("/.netlify/functions/admin-contracts", {
        method: "GET",
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const result = await response.json();
      return result.contracts || [];
    } catch (error) {
      console.error("\u274C Error fetching contracts via admin API:", error);
      throw error;
    }
  },
  // Update contract status using admin privileges
  async updateContractStatus(contractId, status, notes) {
    try {
      const response = await fetch(`/.netlify/functions/admin-contracts?id=${contractId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          status,
          notes: notes || ""
        })
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const result = await response.json();
      return result;
    } catch (error) {
      console.error("\u274C Error updating contract status:", error);
      throw error;
    }
  },
  // Update full contract using admin privileges
  async updateContract(contractId, updateData) {
    try {
      const response = await fetch(`/.netlify/functions/admin-contracts?id=${contractId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          action: "updateFull",
          ...updateData
        })
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const result = await response.json();
      return result;
    } catch (error) {
      console.error("\u274C Error updating contract:", error);
      throw error;
    }
  },
  // Delete contract using admin privileges
  async deleteContract(contractId) {
    try {
      const response = await fetch(`/.netlify/functions/admin-contracts?id=${contractId}`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const result = await response.json();
      return result;
    } catch (error) {
      console.error("\u274C Error deleting contract:", error);
      throw error;
    }
  },
  // Create user using admin privileges
  async createUser(userData) {
    try {
      const response = await fetch("/.netlify/functions/create-user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(userData)
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const result = await response.json();
      return result;
    } catch (error) {
      console.error("\u274C Error creating user via admin API:", error);
      throw error;
    }
  },
  // Test Firebase Admin SDK
  async testFirebaseAdmin() {
    try {
      const response = await fetch("/.netlify/functions/test-firebase-admin");
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const result = await response.json();
      return result;
    } catch (error) {
      console.error("\u274C Error testing Firebase Admin:", error);
      throw error;
    }
  }
};
var admin_contracts_default = adminApi;
export {
  adminApi,
  admin_contracts_default as default
};
